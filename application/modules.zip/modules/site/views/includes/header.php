<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>IOD Ke. | <?php echo $title;?></title>
	<!-- Bootstrap core CSS -->
	<link href="<?php echo base_url()."assets/themes/uoe/";?>css/bootstrap.min.css" rel="stylesheet">
	<!-- Full Calender CSS -->
	<link href="<?php echo base_url()."assets/themes/uoe/";?>css/fullcalendar.css" rel="stylesheet">
	<!-- Owl Carousel CSS -->
	<link href="<?php echo base_url()."assets/themes/uoe/";?>css/owl.carousel.css" rel="stylesheet">
	<!-- Pretty Photo CSS -->
	<link href="<?php echo base_url()."assets/themes/uoe/";?>css/prettyPhoto.css" rel="stylesheet">
	<!-- Bx-Slider StyleSheet CSS -->
	<link href="<?php echo base_url()."assets/themes/uoe/";?>css/jquery.bxslider.css" rel="stylesheet"> 
	<!-- Font Awesome StyleSheet CSS -->
    <link rel="stylesheet" href="<?php echo base_url()."assets/themes/";?>fontawesome/css/font-awesome.css">
	<link href="<?php echo base_url()."assets/themes/uoe/";?>svg/style.css" rel="stylesheet">
	<!-- Widget CSS -->
	<link href="<?php echo base_url()."assets/themes/uoe/";?>css/widget.css" rel="stylesheet">
	<!-- Typography CSS -->
	<link href="<?php echo base_url()."assets/themes/uoe/";?>css/typography.css" rel="stylesheet">
	<!-- Shortcodes CSS -->
	<link href="<?php echo base_url()."assets/themes/uoe/";?>css/shortcodes.css" rel="stylesheet">
	<!-- Custom Main StyleSheet CSS -->
	<link href="<?php echo base_url()."assets/themes/uoe/";?>style.css" rel="stylesheet">
	<!-- Color CSS -->
	<link href="<?php echo base_url()."assets/themes/uoe/";?>css/color.css" rel="stylesheet">
	<!-- Responsive CSS -->
	<link href="<?php echo base_url()."assets/themes/uoe/";?>css/responsive.css" rel="stylesheet">
	<!-- SELECT MENU -->
	<link href="<?php echo base_url()."assets/themes/uoe/";?>css/selectric.css" rel="stylesheet">
	<!-- SIDE MENU -->
	<link rel="stylesheet" href="<?php echo base_url()."assets/themes/uoe/";?>css/jquery.sidr.dark.css">
	<link href="<?php echo base_url()."assets/themes/custom/";?>css/custom.css" rel="stylesheet">
</head>