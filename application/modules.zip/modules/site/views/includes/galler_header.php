<head>
        <meta charset="utf-8" />
        <title>SETSON : : <?php echo $title;?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="keywords" content="HTML5 Template" />
        <meta name="description" content="Metal — A Construction Company Template" />
        <meta name="author" content="zozothemes.com" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <!-- Favicon -->
        <link rel="shortcut icon" href="img/favicon.ico" />
        <!-- Font -->
        <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Arimo:300,400,500,700,400italic,700italic' />
        <link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css' />
        <!-- Font Awesome Icons -->
        <link href='<?php echo base_url()."assets/themes/metal/";?>css/font-awesome.min.css' rel='stylesheet' type='text/css' />
        <!-- Bootstrap core CSS -->
        <link href="<?php echo base_url()."assets/themes/metal/";?>css/bootstrap.min.css" rel="stylesheet" />
        <link href="<?php echo base_url()."assets/themes/metal/";?>css/hover-dropdown-menu.css" rel="stylesheet" />
        <!-- Icomoon Icons -->
        <link href="<?php echo base_url()."assets/themes/metal/";?>css/icons.css" rel="stylesheet" />
        <!-- Revolution Slider -->
        <link href="<?php echo base_url()."assets/themes/metal/";?>css/revolution-slider.css" rel="stylesheet" />
        <link href="<?php echo base_url()."assets/themes/metal/";?>rs-plugin/css/settings.css" rel="stylesheet" />
        <!-- Animations -->
        <link href="<?php echo base_url()."assets/themes/metal/";?>css/animate.min.css" rel="stylesheet" />
        <!-- Owl Carousel Slider -->
        <link href="<?php echo base_url()."assets/themes/metal/";?>css/owl/owl.carousel.css" rel="stylesheet" />
        <link href="<?php echo base_url()."assets/themes/metal/";?>css/owl/owl.theme.css" rel="stylesheet" />
        <link href="<?php echo base_url()."assets/themes/metal/";?>css/owl/owl.transitions.css" rel="stylesheet" />
        <!-- PrettyPhoto Popup -->
        <link href="<?php echo base_url()."assets/themes/metal/";?>css/prettyPhoto.css" rel="stylesheet" />
        <!-- Custom Style -->
        <link href="<?php echo base_url()."assets/themes/metal/";?>css/style.css" rel="stylesheet" />
        <link href="<?php echo base_url()."assets/themes/metal/";?>css/responsive.css" rel="stylesheet" />
        <!-- Color Scheme -->
        <link href="<?php echo base_url()."assets/themes/metal/";?>css/color.css" rel="stylesheet" />
        <script src="<?php echo base_url()."assets/themes/";?>jquery-2.1.4.min.js"></script>
        <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet">
    </head>