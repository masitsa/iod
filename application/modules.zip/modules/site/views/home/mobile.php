<div class="white section-content">
	<div class="container">
        <div class="row">
            
            <div class="col m6">
            	<img src="<?php echo base_url().'assets/img/iphone.png';?>" class="responsive-img" alt="iphone">
            </div>
            
            <div class="col m6">
            	<p>
                	On average our smartbanners increase organic installs by over 500%. We  have generated x installs for our users.. 
                </p>
                
            	<p>
No credit card  details required. Our pricing is simple, we pay your monthly membership fee unless you are generating over 500 installs per month from our banners. And are completely satisfied with the service you are receiving.
                </p>
            </div>
        </div>
        
        <div class="margin-height-60"></div>
        
    </div>
</div>