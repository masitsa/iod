<link href="<?php echo base_url()."assets/themes/counter/";?>dnd-shortcodes.css" rel="stylesheet">
        
<div class="grey lighten-4 section-content" id="installs">
	<div class="container">

        <div class="row">
            <div class="col m12">
        		<h3 class="header center-align grey-text darken-2 generated-first">We have generated</h3>
                
                <div class="dnd_section_content">
                    <div class="dnd_container">
                        <div class="dnd_column_dd_span12 ">
                            <div class="dnd_countdown simple_style " data-value="2016/02/21 00:00:00">
                                <div class="dnd_countdown_inner">
                                    <div class="simple countdown year">
                                    	1
                                    </div>
                                </div>
                                <div class="dnd_countdown_inner">
                                    <div class="simple countdown month">
                                    	0
                                    </div>
                                </div>
                                <div class="dnd_countdown_inner">
                                    <div class="simple countdown day">
                                    	8
                                    </div>
                                </div>
                                <div class="dnd_countdown_inner">
                                    <div class="simple countdown hour">	
                                    	3
                                    </div>
                                </div>
                                <div class="dnd_countdown_inner">
                                    <div class="simple countdown minute">
                                    	8
                                    </div>
                                </div>
                                <div class="dnd_countdown_inner">
                                    <div class="simple countdown second">
                                    	9
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            	
        		<h3 class="header center-align grey-text darken-2 generated-last">installs and counting!</h3>
            </div>
        </div>
    </div>
</div>