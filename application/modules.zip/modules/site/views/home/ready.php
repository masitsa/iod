<!--<div class="blue lighten-2 home-header">-->
<div class="section-content installify-blue">
	<div class="container">
        
        <h3 class="header center-align white-text margin-height-60">Ready to create your smartbanner now?</h3>
        
        <div class="card-content white-text" style="padding-top:0;">
            <div class="center-align" id="preloader2"></div>
            <div class="row no-bottom-margin">
                <form class="col s12">
                	<p class="center-align white-text">
                    	Start by entering your website URL
                    </p>
                    <div class="get-installs footer-signup">
                    	<div class="install-form">
                            <input placeholder="Your website URL" id="website_url2" type="text" class="validate">
                            <button type="button" class="btn amber" id="google_signup2">
                                <!--<span class="icon"><i class="fa fa-google"></i></span>-->
                                Get more installs
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
		
        <div class="margin-height-60"></div>
    </div>
</div>

<div class="container installify-blue">
    <div class="divider"></div>
</div>