
			<!--TRAINING WRAP START-->
			<section class="edu2_tarining_bg">
				<div class="container">
					<div class="row">
						<div class="col-md-4">
							<div class="kf_edu2_training_des">
								<figure>
									<img src="<?php echo base_url().'assets/images/';?>institute.png" alt=""/>
								</figure>
							</div>
						</div>

						<div class="col-md-8">
							<div class="edu2_training_wrap">
								<h2>Register as one of our members today</h2>
								<!--COUNTDOWN START-->
								<ul class="countdown">
									<li>
										<span class="days">1</span>
									</li>
									<li>
										<span class="hours">1</span>
									</li>
									<li>
										<span class="minutes">4</span>
									</li>
									<li>
										<span class="seconds last">3</span>
									</li>
								</ul>
								<!--COUNTDOWN END-->
								<a href="<?php echo site_url().'register';?>" class="btn-1">REGISTER NOW</a>
							</div>

						</div>
					</div>
				</div>
			</section>
			<!--TRAINING WRAP END-->
