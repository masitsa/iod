<?php
	if($profiles->num_rows() > 0)
	{
		$product = $profiles->result();
		
		foreach($product as $prods)
		{
			$username = $prods->username;
			$name = $prods->name;
			$id = $prods->id;
			$web_name = $this->profile_model->create_web_name($username);
			$number = '';
			
			echo
				$number.'
					<li class="chat-item">
						<a href="chat-single.html" class="item-link item-content" onclick="chat_single('.$id.');">
							<div class="item-media">
								<div class="image-icon ">
									<img src="user.png">
								</div>
							</div>
							<div class="item-inner">
								<div class="item-title-row">
									<div class="item-title">'.$name.'</div>
								</div>
							</div>
						</a>
					</li>
			';
		}
	}
	
	else
	{
		echo ' We are unable to find any profiles';
	}
?>